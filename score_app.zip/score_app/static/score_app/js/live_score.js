const socket = new WebSocket('ws://localhost:8000/ws/live_scores/');
console.log(socket);

socket.onmessage = function(event) {
    const data = JSON.parse(event.data);
    console.log("Message received:", data);

    // Check if the placeholder element exists
    const liveScoresDiv = document.getElementById('live-scores');
    if (!liveScoresDiv) {
        console.error("The element with id 'live-scores' is missing.");
        return;
    }

    // Check if the data is valid
    if (data.team1 && data.team2) {
        // Update the live scores
        liveScoresDiv.innerHTML = `
        <div class="container mt-4" id="live-scores">
            <h1 class="text-center">Live Cricket Scores</h1>
            <div class="score-board mt-4">
                <div class="match-card">
                    <div class="match-header">
                        <span class="team-name">${data.team1}</span>
                        <span class="team-name">${data.team2}</span>
                    </div>
                    <div class="score-section">
                        <div class="team-score">
                            <span>${data.team1_runs}/${data.team1_wickets}</span> 
                        </div>
                        <div class="team-score">
                            <span>${data.team2_runs}/${data.team2_wickets}</span>
                        </div>
                    </div>
                    <div class="match-details">
                        <p><strong>Overs:</strong>${data.overs}</p>
                    </div>
                </div>
            </div>
        </div>
        `;
    } else {
        console.error("Invalid data received:", data);
    }
};

socket.onerror = function(error) {
    console.error("WebSocket error:", error);
};