from django.apps import AppConfig


class ScoreAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'score_app'
